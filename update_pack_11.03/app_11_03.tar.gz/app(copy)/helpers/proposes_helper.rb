module ProposesHelper
	
end
